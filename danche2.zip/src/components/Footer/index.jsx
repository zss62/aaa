import React,{Component} from 'react';
import './index.less'
export default class Footer extends Component{
  render(){
    return (
      <div className="footer">
            版权所有：慕课网&河畔一角 （推荐使用谷歌浏览器，可以获得更加的操作页）
      </div>
    )
  }
}