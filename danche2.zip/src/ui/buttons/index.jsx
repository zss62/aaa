import React,{Component} from 'react';
import {Card,Button} from 'antd';

export default class Buttons extends Component{
  render(){
    return(
      <div>
        <Card title="基本按钮">

        </Card>
      </div>
    )
  }
}
